from flask import Flask, render_template, request, jsonify
import pandas as pd
from utils import model_predict  # Importing model_predict function from utils.py

app = Flask(__name__)

# Load dataset from CSV
dataset = pd.read_csv('malicious_phish.csv')

@app.route("/")
def home():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    url = request.form.get('content')  # Update to match the textarea name in the HTML
    prediction = model_predict(url)
    return render_template("index.html", prediction=prediction, email=url)  # Pass email=url to render the entered URL back

# API endpoint to make predictions
@app.route('/api/predict', methods=['POST'])
def predict_api():
    data = request.get_json(force=True)
    url = data['content']  # Update to match the key for the URL in the JSON request
    prediction = model_predict(url)
    return jsonify({'prediction': prediction, 'content': url})  # Update keys in the JSON response

# Route to access the loaded dataset
@app.route('/dataset')
def get_dataset():
    return dataset.to_html()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug=True)
