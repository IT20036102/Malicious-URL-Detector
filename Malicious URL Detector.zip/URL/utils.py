# utils.py

# Import necessary libraries and modules for your model if needed
import pandas as pd

# Load your model or relevant data
# For demonstration purposes, assuming the existence of a dataset and a model

# Load dataset
dataset = pd.read_csv('malicious_phish.csv')  # Update with your dataset

# Example prediction function (replace with your actual model prediction logic)
def model_predict(url):
    # Add your model prediction logic here based on the dataset and your model
    # This is a placeholder - replace it with your actual prediction logic

    # Here, assuming the dataset contains columns: 'URL' and 'Label' for predictions
    # Replace this with your model's prediction code using the loaded dataset
    # For demonstration purposes, assuming 'URL' is the column for URLs and 'Label' is the column for categories

    # Example code to fetch a prediction for the URL
    predicted_label = predict_label_for_url(url, type)  # Implement your prediction method
    return predicted_label

# Function to predict the label for the URL
def predict_label_for_url(url, type):
    # Replace this logic with your actual model's prediction based on the dataset
    # Here, a placeholder logic to demonstrate prediction using the dataset
    # You should implement your actual prediction logic here

    # Search for the URL in the dataset and return its label
    url_row = dataset.loc[dataset['url'] == url]
    if not url_row.empty:
        predicted_label = url_row['type'].values[0]
        return predicted_label
    else:
        return "Unknown"  # Return "Unknown" if the URL is not found
